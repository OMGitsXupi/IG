
- MOSTRAR CONO: pulsando la tecla 'V'
- MOSTRAR ESFERA: pulsando la tecla 'B'
- MOSTRAR OBJETO POR REVOLUCIÓN CON PERFIL POR PLY: pulsando la tecla 'L'
	
perfil.ply es el del peón, he modificado el makefile para que sea el segundo argumento que se le pasa al ejecutable.
