FUNCIONALIDAD EXTRA: pulsar la tecla 'r' para colores aleatorios en las caras
