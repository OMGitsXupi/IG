﻿Con la tecla 'K' se muestran las figuras que he creado (un suelo y un personaje, el cual está inspirado en Kirby).

Con las teclas 'F5' y 'F6' se mueven los brazos y los pies, respectivamente. Estos ya tienen definido un rango de movimiento así que oscilan si se mantiene pulsado.

Con las teclas 'Y','G','H' y 'J' se mueve el personaje por encima del suelo.

He modificado el Makefile para que con 'make x' o 'make redo', se ejecute directamente.